package org.example.testapiq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestAPIApplicationTests {

    @Test
    void contextLoads() {
    }

}
