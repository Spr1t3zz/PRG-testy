package org.example.testapiq;

import java.util.List;

public class Continent {

    private List<Country> countries;
    private String continent;
    private int year;

    public Continent(List<Country> countries, String continent, int year) {
        this.countries = countries;
        this.continent = continent;
        this.year = year;
    }

    public String getContinent() {
        return continent;
    }

    public int getYear() {
        return year;
    }

    public int getCountryCount() {
        return countries.size();
    }

    public long getTotalPopulation() {
        return countries.stream()
                .mapToLong(Country::getPopuation)
                .sum();
    }

    public double getAverageLifeExpectation() {
        return countries.stream()
                .mapToDouble(Country::getLifeExpectation)
                .average()
                .getAsDouble();
    }

    public double getAverageGDPPercapita() {
        return countries.stream()
                .mapToDouble(Country::getGDPPercapita)
                .average()
                .getAsDouble();
    }

    public String getHighestLifeExpCountry() {
        return countries.stream()
                .max((c1, c2) -> Double.compare(c1.getLifeExpectation(), c2.getLifeExpectation()))
                .map(Country::getCountry)
                .get();
    }

    public String getLowestLifeExpCountry() {
        return countries.stream()
                .min((c1, c2) -> Double.compare(c1.getLifeExpectation(), c2.getLifeExpectation()))
                .map(Country::getCountry)
                .get();
    }
}
