package org.example.testapiq;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

@RestController
public class TestAPIController {

    // 1. UKOL
    // http://localhost:8080/api/gapminder/population?year=2007&min=50000000&continent=Asia
    @GetMapping("/api/gapminder/population")
    public List<Country> getPopByYear(
            @RequestParam int year,
            @RequestParam long min,
            @RequestParam String continent
    ) {
        List<Country> countries = parseCsv();

        return countries.stream()
                .filter(c -> c.getYear() == year)
                .filter(c -> c.getPopuation() >= min)
                .filter(c -> continent == null || c.getContinent().equalsIgnoreCase(continent))
                .toList();
    }

//--------------------------------------------------------------------------------------------------------------------//

    // 2. UKOL
    // http://localhost:8080/api/gapminder/continents/stats?year=2007
    @GetMapping("/api/gapminder/continents/{continent}/stats")
    public Continent getContinentStatsByYear(
            @PathVariable String continent,
            @RequestParam int year
    ) {
        List<Country> countries = parseCsv().stream()
                .filter(c -> c.getYear() == year)
                .filter(c -> c.getContinent().equalsIgnoreCase(continent))
                .toList();

        return new Continent(countries, continent, year);
    }

//--------------------------------------------------------------------------------------------------------------------//

    // 3. UKOL
    // http://localhost:8080/api/gapminder/countries/India/population-change?from=1952&to=2007
    @GetMapping("/api/gapminder/countries/{country}/population-change")
    public PopComparison getPopComparison(
            @PathVariable String country,
            @RequestParam int from,
            @RequestParam int to
    ) {
        List<Country> countries = parseCsv();

        Country fromCountry = null;
        Country toCountry = null;

        for (Country c : countries) {
            if (c.getCountry().equalsIgnoreCase(country) && c.getYear() == from) {
                fromCountry = c;
            }
            if (c.getCountry().equalsIgnoreCase(country) && c.getYear() == to) {
                toCountry = c;
            }
        }

        return new PopComparison(fromCountry, toCountry);
    }

//--------------------------------------------------------------------------------------------------------------------//

    private List<Country> parseCsv() {
        try {
            var inputStream = getClass().getClassLoader()
                    .getResourceAsStream("gapminderDataFiveYear.csv");
            if (inputStream == null) throw new RuntimeException("CSV not found on classpath");

            return new BufferedReader(new InputStreamReader(inputStream))
                    .lines()
                    .skip(1)
                    .map(row -> row.split(","))
                    .map(row -> new Country(
                            row[0],
                            Integer.parseInt(row[1]),
                            (long) Double.parseDouble(row[2]),
                            row[3],
                            Double.parseDouble(row[4]),
                            Double.parseDouble(row[5])
                    ))
                    .toList();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}