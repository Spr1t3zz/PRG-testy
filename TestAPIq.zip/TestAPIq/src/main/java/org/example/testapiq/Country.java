package org.example.testapiq;

public class Country {

    private final String country;
    private final int year;
    private final long pop;
    private final String continent;
    private final double lifeExp;
    private final double gdpPercap;

    public Country(String country, int year, long pop, String continent, double lifeExp, double gdpPercap) {
        this.country = country;
        this.year = year;
        this.pop = pop;
        this.continent = continent;
        this.lifeExp = lifeExp;
        this.gdpPercap = gdpPercap;
    }

    public String getCountry() {
        return country;
    }

    public int getYear() {
        return year;
    }

    public long getPopuation() {
        return pop;
    }

    public String getContinent() {
        return continent;
    }

    public double getLifeExpectation() {
        return lifeExp;
    }

    public double getGDPPercapita() {
        return gdpPercap;
    }
}
