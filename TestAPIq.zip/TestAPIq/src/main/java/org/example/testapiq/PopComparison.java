package org.example.testapiq;

public class PopComparison {

    private Country from;
    private Country to;

    public PopComparison(Country from, Country to) {
        this.from = from;
        this.to = to;
    }

    public String getCountry() {
        return from.getCountry();
    }

    public String getContinent() {
        return from.getContinent();
    }

    public int getFromYear() {
        return from.getYear();
    }

    public int getToYear() {
        return to.getYear();
    }

    public long getPopulationFrom() {
        return from.getPopuation();
    }

    public long getPopulationTo() {
        return to.getPopuation();
    }

    public long getPopulationChange() {
        return to.getPopuation() - from.getPopuation();
    }

    public double getPopulationChangePercent() {
        return ((double) (to.getPopuation() - from.getPopuation()) / from.getPopuation()) * 100;
    }
}